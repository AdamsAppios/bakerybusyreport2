import React from "react";
import Reroute from "./projects/Reroute";

const App = () => {
  return (
    <Reroute></Reroute>
  );
};

export default App;
