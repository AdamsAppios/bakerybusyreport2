import React from "react";

const GloryBee = () => (
  <div>
    <h2>Hello Glorybee</h2>
  </div>
);

export default GloryBee;
