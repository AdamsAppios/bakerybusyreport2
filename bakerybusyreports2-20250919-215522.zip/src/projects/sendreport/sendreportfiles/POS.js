import React, { useMemo, useState } from 'react';
import { Form, Button } from 'react-bootstrap';

/** Catalog (from your price sheet) */
const BREADS = [
  // Left column
  { name: 'BAHUG2X', price: 7 },
  { name: 'CHEESE BREAD', price: 7 },
  { name: 'CHEESE BUNS', price: 7 },
  { name: 'CHICHAY', price: 6 },
  { name: 'CHOCO CUPCAKE', price: 7 },
  { name: 'CHOCO LANAY', price: 7 },
  { name: 'CINNAMON', price: 8 },
  { name: 'CINNAMON ROLL', price: 10 },
  { name: 'CLOVER', price: 6 },
  { name: 'COCO BREAD', price: 7 },
  { name: 'CRINKLES', price: 8 },
  { name: 'DESAL', price: 5 },
  { name: 'EGG BREAD', price: 7 },
  { name: 'ELORDE', price: 5 },
  { name: 'ENSAI BIG', price: 13 },
  { name: 'ENSAI CHEESE', price: 11 },
  { name: 'ENSAI CHOCO', price: 6 },
  { name: 'ENSAI PLAIN', price: 6 },
  { name: 'ENSAI RAISIN', price: 13 },
  { name: 'ENSAI UBE', price: 6 },
  { name: 'EVERLASTING', price: 5 },
  // Right column
  { name: 'FOODMAN', price: 6 },
  { name: 'FRANCIS', price: 6 },
  { name: 'GERMAN', price: 6 },
  { name: 'GRACIOSA', price: 23 },
  { name: 'KING ROLL', price: 6 },
  { name: 'LOAF BREAD', price: 40 },
  { name: 'MAIS2X', price: 5 },
  { name: 'MAMON', price: 6 },
  { name: 'MARBLE CUPCAKE', price: 7 },
  { name: 'MUSHROOM', price: 5 },
  { name: 'PIGPIE', price: 12 },
  { name: 'POLVORON', price: 8 },
  { name: 'SLICED BREAD', price: 55 },
  { name: 'SPANISH BREAD', price: 7 },
  { name: 'SUGAR BUNS', price: 6 },
  { name: 'SUNFLOWER', price: 8 },
  { name: 'SWEETHEART', price: 6 },
  { name: 'TOASTED', price: 10 },
  { name: 'TORTA', price: 13 },
  { name: 'UBE CUPCAKE', price: 6 },
  { name: 'UBE TWIST', price: 6 },
];

const peso = (n) => `₱ ${Number(n || 0).toLocaleString('en-PH')}`;

export default function POS() {
  const [q, setQ] = useState('');
  const [qtyMap, setQtyMap] = useState({}); // { 'ENSAI UBE': 2, ... }

  const norm = (s) => s.replace(/\s+/g, '').toLowerCase();
  const filtered = useMemo(() => {
    const n = norm(q);
    if (!n) return BREADS;
    return BREADS.filter((b) => norm(b.name).startsWith(n));
  }, [q]);

  const step = (name, delta) => {
    setQtyMap((m) => {
      const cur = Number(m[name] || 0);
      const next = Math.max(0, cur + delta);
      return { ...m, [name]: next };
    });
  };

  // Sanitise live entry: only digits, strip leading zeros (keeps single 0).
  const changeQty = (name, raw) => {
    let s = String(raw ?? '');
    s = s.replace(/\D/g, '');          // digits only
    s = s.replace(/^0+(?=\d)/, '');    // remove leading zeros if there are more digits
    const n = s === '' ? 0 : parseInt(s, 10);
    setQtyMap((m) => ({ ...m, [name]: n }));
  };

  const total = useMemo(
    () => BREADS.reduce((sum, b) => sum + (qtyMap[b.name] || 0) * b.price, 0),
    [qtyMap]
  );

  // ----- live summary text (blank if no purchase)
  const summaryText = useMemo(() => {
    const chosen = BREADS.filter((b) => (qtyMap[b.name] || 0) > 0);
    if (!chosen.length) return '';
    const lines = chosen.map((b) => {
      const qty = qtyMap[b.name] || 0;
      const amount = qty * b.price;
      return `${b.name} — ${qty} × ${peso(b.price)} = ${peso(amount)}`;
    });
    lines.push(`\nTotal: ${peso(total)}`);
    return lines.join('\n');
  }, [qtyMap, total]);

  const clearAll = () => setQtyMap({});
  const clearSearch = () => setQ('');

  return (
    <div className="pos-wrap">
      <div className="pos-search">
              {/* --- Summary textarea (expandable). Empty when no purchases. --- */}
        <div className="pos-summary mt-2 mb-3">
            <Form.Label className="fw-bold">Summary</Form.Label>
            <Form.Control
            as="textarea"
            className="expandable-textarea"
            rows={5}
            value={summaryText}
            readOnly
            placeholder="(summary is blank until you add items)"
            />
        </div>
        <div className="pos-search-row">
          <Form.Control
            type="text"
            value={q}
            placeholder="Search bread… (type: e, en, ensai…)"
            onChange={(e) => setQ(e.target.value)}
          />
          <Button
            variant="outline-secondary"
            size="sm"
            onClick={clearSearch}
            disabled={!q}
            title="Clear search"
          >
            Clear Search
          </Button>
          <Button variant="secondary" size="sm" onClick={clearAll}>
            Clear POS
          </Button>
        </div>
        <div className="small text-muted mt-1">
          Tip: type the first letters (e.g., <strong>en</strong> → ENSAI items).
        </div>
      </div>


      <div className="pos-list">
        {filtered.map((b) => {
          const qty = qtyMap[b.name] || 0;
          const amount = qty * b.price;
          return (
            <div key={b.name} className="pos-item">
              <div className="pos-meta">
                <div className="pos-name">{b.name}</div>
                <div className="pos-price">{peso(b.price)}</div>
              </div>

              <div className="stepper">
                <Button
                  variant="light"
                  className="step-btn"
                  disabled={qty <= 0}
                  onClick={() => step(b.name, -1)}
                  aria-label={`- ${b.name}`}
                >
                  –
                </Button>

                <Form.Control
                  type="text"               /* text + numeric filter avoids odd leading-zero behavior */
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={String(qty)}        /* canonical display (no leading zeros) */
                  onChange={(e) => changeQty(b.name, e.target.value)}
                  className="money-input"
                />

                <Button
                  variant="light"
                  className="step-btn"
                  onClick={() => step(b.name, +1)}
                  aria-label={`+ ${b.name}`}
                >
                  +
                </Button>
              </div>

              <div className="pos-amount">
                {qty > 0 ? `${qty} × ${peso(b.price)} = ` : ''}
                <strong>{peso(amount)}</strong>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating total for POS */}
      <div className="floating-pos-total" aria-live="polite" role="status">
        <span className="floating-total-label">Total:</span>
        <span className="floating-total-amount">{peso(total)}</span>
      </div>
    </div>
  );
}
