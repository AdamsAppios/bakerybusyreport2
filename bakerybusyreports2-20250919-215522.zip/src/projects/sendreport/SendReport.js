import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Tab, Tabs, Container } from 'react-bootstrap';
import './SendReport.css';
import MoneySales from './sendreportfiles/MoneySales';
import OtherSales from './sendreportfiles/OtherSales';
import CoffeeSales from './sendreportfiles/CoffeeSales';
import Copytoclipboard from './helpers/Copytoclipboard';
import POS from './sendreportfiles/POS';

// Helper function to get the current date in Manila (Philippine) time as "YYYY-MM-DD"
const getPhilippineDate = () => {
  const now = new Date();
  // Convert current time to Manila time
  const manilaString = now.toLocaleString("en-US", { timeZone: "Asia/Manila" });
  const manilaDate = new Date(manilaString);
  const year = manilaDate.getFullYear();
  const month = (manilaDate.getMonth() + 1).toString().padStart(2, '0');
  const day = manilaDate.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Format "YYYY-MM-DD" to "September 7, 2025" using PH timezone
const formatDatePHLong = (yyyyMmDd) => {
  if (!yyyyMmDd) return '';
  const [y, m, d] = yyyyMmDd.split('-').map(Number);
  const asUTC = new Date(Date.UTC(y, (m || 1) - 1, d || 1));
  return asUTC.toLocaleDateString('en-US', {
    timeZone: 'Asia/Manila',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
};

const SendReport = () => {
  const [tabValue, setTabValue] = useState('moneySales');
  const [reportText, setReportText] = useState('Date: \nCashier: \nTotal: 0');
  const [formData, setFormData] = useState({
    date: getPhilippineDate(),  // Set default Philippine date here
    time: '',
    cashier: '',
    cash1000: '',
    cash500: '',
    cash200: '',
    cash100: '',
    cash50: '',
    cash20: '',
    coins10: '',
    coins5: '',
    coins1: '',
    totalCash: 0,
    totalSales: '',
    sb: '',
    coins: '',
    toasted: '',
    nsSale: '',
    nsStocks: '',
    sd: '',
    mineral: '',
    mantika: '',
    plasticSB: '',
    plasticLoaf: '',
    loaf: '',
    plastic3: '',
    plastic6: '',
    plasticTiny: '',
    pullouts: '',
    accounts: '',
    workers: '',
    expenses: '',
    totalExpenses: 0,
    coffeeDate: '',
    halin: '',
    capuccino: '',
    threeInOne: '',
    caramel: '',
    cupsBeg: '',
    cupsEnd: '',
    coffeeReport: 'Good PM Sales sa coffee\ndate: '
  });

  const handleTabChange = (k) => {
    setTabValue(k);
  };

 const handleInputChange = (e) => {
   const { name, value } = e.target;

   // Money fields (keep your current behavior that allows '+')
   const moneyFields = [
     'cash1000','cash500','cash200','cash100','cash50','cash20','coins10','coins5','coins1'
   ];
   if (moneyFields.includes(name)) {
     if (/^[0-9+]*$/.test(value)) setFormData(prev => ({ ...prev, [name]: value }));
     return;
   }

   // Expenses textarea → compute sum of numbers after '=' per line
   if (name === 'expenses') {
     const sum = value
       .split(/\n+/)
       .map(line => {
         const idx = line.lastIndexOf('=');
         if (idx === -1) return 0;
         const num = parseFloat(line.slice(idx + 1).replace(/[^0-9.\-]/g, '').trim());
         return isNaN(num) ? 0 : num;
       })
       .reduce((a, b) => a + b, 0);
     setFormData(prev => ({ ...prev, expenses: value, totalExpenses: sum }));
     return;
   }

   // Everything else
   setFormData(prev => ({ ...prev, [name]: value }));
   };

  const clearMoneyInputs = () => {
    const todayPH = getPhilippineDate();
    setFormData(prev => ({
      ...prev,
      // Money tab only:
      date: todayPH,
      time: '',
      cashier: '',
      cash1000: '',
      cash500: '',
      cash200: '',
      cash100: '',
      cash50: '',
      cash20: '',
      coins10: '',
      coins5: '',
      coins1: '',
      totalCash: 0,
    }));
  };

  
  useEffect(() => {
    // Helper function to evaluate expressions like "5+23"
    const evaluateExpression = (expr) => {
      if (!expr) return 0;
      if (expr.includes('+')) {
        return expr
          .split('+')
          .reduce((sum, part) => sum + (Number(part.trim()) || 0), 0);
      }
      return Number(expr) || 0;
    };

    const calculateReport = () => {
      let totalCash = 0;
      let report = '';
      if (formData.cash1000 > 0) {
        const qty = Number(formData.cash1000) || 0;
        const subtotal = 1000 * qty;
        report += `1000x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
     if (formData.cash500 > 0 ) {
        const qty = Number(formData.cash500) || 0;
        const subtotal = 500 * qty;
        report += `500x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.cash200 > 0) {
        const qty = Number(formData.cash200) || 0;
        const subtotal = 200 * qty;
        report += `200x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.cash100 > 0) {
        const qty = Number(formData.cash100) || 0;
        const subtotal = 100 * qty;
        report += `100x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.cash50 > 0) {
        const qty = Number(formData.cash50) || 0;
        const subtotal = 50 * qty;
        report += `50x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.cash20 > 0) {
        const qty = Number(formData.cash20) || 0;
        const subtotal = 20 * qty;
        report += `20x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.coins10 >0) {
        const qty = Number(formData.coins10) || 0;
        const subtotal = 10 * qty;
        report += `10x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }
      if (formData.coins5 > 0) {
        const qty = Number(formData.coins5) || 0;
        const subtotal = 5 * qty;
        report += `5x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }

      if (formData.coins1 > 0) {
        const qty = Number(formData.coins1) || 0;
        const subtotal = 1 * qty;
        report += `1x${qty} = ${subtotal}\n`;
        totalCash += subtotal;
      }


      // Update the totalCash in state
      setFormData((prevData) => ({
        ...prevData,
        totalCash
      }));

      let otherSalesReport = '';
      if (formData.totalSales) otherSalesReport += `Total_Sales = ${formData.totalSales}\n`;
      if (formData.sb) otherSalesReport += `SB = ${formData.sb}\n`;
      if (formData.coins) otherSalesReport += `Coins = ${formData.coins}\n`;
      if (formData.toasted) otherSalesReport += `Toasted = ${formData.toasted}\n`;
      if (formData.nsSale) otherSalesReport += `NSSale = ${formData.nsSale}\n`;
      if (formData.nsStocks) otherSalesReport += `NSStocks = ${formData.nsStocks}\n`;
      if (formData.sd) otherSalesReport += `SD = ${formData.sd}\n`;
      if (formData.mineral) {
        const m = Number(formData.mineral) || 0;
        otherSalesReport += `Mineral=${m}x15 = ${m * 15}\n`;
      }
      if (formData.mantika) otherSalesReport += `Mantika = ${formData.mantika}\n`;
      if (formData.plasticSB) otherSalesReport += `Plastic SB = ${formData.plasticSB}\n`;
      if (formData.plasticLoaf) otherSalesReport += `Plastic Loaf = ${formData.plasticLoaf}\n`;
      if (formData.loaf) otherSalesReport += `Loaf = ${formData.loaf}\n`;
      if (formData.plastic3) otherSalesReport += `Plastic_No3 = ${formData.plastic3}\n`;
      if (formData.plastic6) otherSalesReport += `Plastic_No6 = ${formData.plastic6}\n`;
      if (formData.plasticTiny) otherSalesReport += `Plastic Tiny = ${formData.plasticTiny}\n`;
      if (formData.pullouts) otherSalesReport += `\nPullouts = \n${formData.pullouts}\n\n`;
      if (formData.accounts) otherSalesReport += `Accounts = \n${formData.accounts}\n\n`;
      if (formData.workers) otherSalesReport += `Workers = \n${formData.workers}\n`;
      const hasExpText = !!(formData.expenses && formData.expenses.trim().length > 0);
      const totalExp = Number(formData.totalExpenses || 0);
      if (hasExpText) {
         otherSalesReport += `\nExpenses\n${formData.expenses}\nTotal Expenses: ${totalExp}\n`;
      }
      let coffeeSalesReport = '';
      if (formData.halin) coffeeSalesReport += `Halin = ${formData.halin}\n`;
      if (formData.capuccino) coffeeSalesReport += `Capuccino = ${formData.capuccino}\n`;
      if (formData.threeInOne) coffeeSalesReport += `3in1 = ${formData.threeInOne}\n`;
      if (formData.caramel) coffeeSalesReport += `Caramel = ${formData.caramel}\n`;
      if (formData.cupsBeg) coffeeSalesReport += `Cups Beginning = ${formData.cupsBeg}\n`;
      if (formData.cupsEnd) coffeeSalesReport += `Cups Ending = ${formData.cupsEnd}\n`;

      const combinedReport =
       `Date: ${formatDatePHLong(formData.date)}\nCashier: ${formData.cashier} - ${formData.time}\n${report}Total: ${totalCash}` +
         (otherSalesReport ? `\n\n${otherSalesReport}` : '') +
         (coffeeSalesReport ? `\n\n${coffeeSalesReport}` : '');

      setReportText(combinedReport);
    };

    calculateReport();
  }, [formData]);

  const handleCopyReport = async () => {
    // Insert a zero-width space after every newline
    const modifiedText = reportText.replace(/\n/g, "\n\u200B");
    try {
      await navigator.clipboard.writeText(modifiedText);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const handleEraseAll = () => {
    setFormData({
      date: getPhilippineDate(),
      time: '',
      cashier: '',
      cash1000: '',
      cash500: '',
      cash200: '',
      cash100: '',
      cash50: '',
      cash20: '',
      coins10: '',
      coins5: '',
      coins1: '',
      totalCash: 0,
      totalSales: '',
      sb: '',
      coins: '',
      toasted: '',
      nsSale: '',
      nsStocks: '',
      sd: '',
      mineral: '',
      mantika: '',
      plasticSB: '',
      plasticLoaf: '',
      loaf: '',
      plastic3: '',
      plastic6: '',
      plasticTiny: '',
      pullouts: '',
      accounts: '',
      workers: '',
      coffeeDate: '',
      halin: '',
      capuccino: '',
      threeInOne: '',
      caramel: '',
      cupsBeg: '',
      cupsEnd: '',
      coffeeReport: 'Good PM Sales sa coffee\ndate: ',
      expenses : '',
      totalExpenses :0,
    });
  };

  return (
    <Container>
      {/* Render the Copytoclipboard component in place of the old buttons */}
      <Copytoclipboard 
        stringReport={reportText} 
        handleEraseAll={handleEraseAll} 
        copyButtonLabel="Copy Report" 
        eraseButtonLabel="Erase All" 
      />
      <Tabs activeKey={tabValue} onSelect={handleTabChange} className="mb-3 custom-tabs">
        <Tab eventKey="moneySales" title="Money Sales">
          <MoneySales
            formData={formData}
            handleInputChange={handleInputChange}
            onClearMoney={clearMoneyInputs}
          />
        </Tab>
        <Tab eventKey="otherSales" title="Other Sales">
          <OtherSales formData={formData} handleInputChange={handleInputChange} />
        </Tab>
        <Tab eventKey="coffeeSales" title="Coffee Sales">
          <CoffeeSales formData={formData} handleInputChange={handleInputChange} />
        </Tab>
        <Tab eventKey="pos" title="POS">
          <POS />
        </Tab>
      </Tabs>
    </Container>
  );
};

export default SendReport;
